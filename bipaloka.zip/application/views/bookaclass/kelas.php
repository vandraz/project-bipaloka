<br>
<br>
<h2 style="text-align: center;padding-bottom: 5%">"Choosing Section Class"</h2>
<div class="container">
    <div class="row">
        <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="..." alt="Card image cap">
                <div class="card-body">
                  <h5 class="card-title">language Counseling Course</h5>
                  <h5 class="card-title">$8.5</h5>
                  <h6 class="card-title">per session</h6>
                  <h6 class="card-title">Konsultasi Bahasa Indonesia pad Tutor Penutur Asli</h6>
                  <hr>
                  <p>- 1 x Pertemuan (45')<br>
                      - Konsultasi tata bahasa dan latihan pengucapan<br>
                     - Ringkasan konseling dan saran materi yang terkait<br><br><hr>

                  <a href="#" class="btn-primary" style="width: 100px">Book</a>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="..." alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">language Counseling Course</h5>
                    <h5 class="card-title">$8.5</h5>
                    <h6 class="card-title">per session</h6>
                    <h6 class="card-title">Konsultasi Bahasa Indonesia pad Tutor Penutur Asli</h6>
                    <hr>
                    <p>- 1 x Pertemuan (45')<br>
                        - Konsultasi tata bahasa dan latihan pengucapan<br>
                        - Ringkasan konseling dan saran materi yang terkait<br><br><hr>
                    <a href="#" class="btn-primary" style="width: 100px">Book</a>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="..." alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">language Counseling Course</h5>
                    <h5 class="card-title">$8.5</h5>
                    <h6 class="card-title">per session</h6>
                    <h6 class="card-title">Konsultasi Bahasa Indonesia pad Tutor Penutur Asli</h6>
                    <hr>
                    <p>- 1 x Pertemuan (45')<br>
                        - Konsultasi tata bahasa dan latihan pengucapan<br>
                       - Ringkasan konseling dan saran materi yang terkait<br><br><hr>
                    <a href="#" class="btn-primary" style="width: 100px">Book</a>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="..." alt="Card image cap">
                <div class="card-body">
                  <h5 class="card-title">language Counseling Course</h5>
                  <h5 class="card-title">$8.5</h5>
                  <h6 class="card-title">per session</h6>
                  <h6 class="card-title">Konsultasi Bahasa Indonesia pad Tutor Penutur Asli</h6>
                  <hr>
                  <p>- 1 x Pertemuan (45')<br>
                      - Konsultasi tata bahasa dan latihan pengucapan<br>
                     - Ringkasan konseling dan saran materi yang terkait<br><br><hr>

                  <a href="#" class="btn-primary" style="width: 100px">Book</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('a').click(function(){
       window.location.href = "<?php echo site_url('bookaclass/payment') ?>";
    });
    
</script>