<br>
<br>
<br>
<h2 style="text-align: center">Our Material</h2>
<hr>
<div class="container">
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-9 col-xs-12">
		    <article>
		        <div class="row">
		            <div class="col-sm-6 col-md-4">
		                <figure>
		                   <img src="<?php echo base_url('assets/asset_web/short-course.png') ?>" style="height: 100px">
		                </figure>
		            </div>
		            <div class="col-sm-6 col-md-8">
		                <span class="label label-default pull-right"><i class="glyphicon glyphicon-comment"></i>50</span>
		                <h4>Download Materi I</h4>
		                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
		                <section>
		                    <i class="glyphicon glyphicon-folder-open"></i>Bootstrap
		                    <i class="glyphicon glyphicon-user"></i>RaymondDragon
		                    <i class="glyphicon glyphicon-calendar"></i>1395/12/21
		                    <i class="glyphicon glyphicon-eye-open"></i>10000
                                    <a href="#" class="btn-default btn-sm pull-right">Download ... </a>
		                </section>
		            </div>
		        </div>
		    </article>
		    <br>
		    <article>
		        <div class="row">
		            <div class="col-sm-6 col-md-4">
		                <figure>
		                    <img src="<?php echo base_url('assets/asset_web/short-course.png') ?>" style="height: 100px">
		                </figure>
		            </div>
		            <div class="col-sm-6 col-md-8">
		                <span class="label label-default pull-right"><i class="glyphicon glyphicon-comment"></i>50</span>
		                <h4>Download Materi II</h4>
		                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
		                <section>
		                    <i class="glyphicon glyphicon-folder-open"></i>Bootstrap
		                    <i class="glyphicon glyphicon-user"></i>RaymondDragon
		                    <i class="glyphicon glyphicon-calendar"></i>1395/12/21
		                    <i class="glyphicon glyphicon-eye-open"></i>10000
		                    <a href="#" class="btn-default btn-sm pull-right">Download ... </a>
		                </section>
		            </div>
		        </div>
		    </article>
                    <br>
		    
		    <article>
		        <div class="row">
		            <div class="col-sm-6 col-md-4">
		                <figure>
		                    <img src="<?php echo base_url('assets/asset_web/short-course.png') ?>" style="height: 100px">
		                </figure>
		            </div>
		            <div class="col-sm-6 col-md-8">
		                <span class="label label-default pull-right"><i class="glyphicon glyphicon-comment"></i>50</span>
		                <h4>Download Materi III</h4>
		                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
		                <section>
		                    <i class="glyphicon glyphicon-folder-open"></i>Bootstrap
		                    <i class="glyphicon glyphicon-user"></i>RaymondDragon
		                    <i class="glyphicon glyphicon-calendar"></i>1395/12/21
		                    <i class="glyphicon glyphicon-eye-open"></i>10000
		                    <a href="#" class="btn-default btn-sm pull-right">Download ... </a>
		                </section>
		            </div>
		        </div>
		    </article>
                    <br>
		    
		    <article>
		        <div class="row">
		            <div class="col-sm-6 col-md-4">
		                <figure>
		                    <img src="<?php echo base_url('assets/asset_web/short-course.png') ?>" style="height: 100px">
		                </figure>
		            </div>
		            <div class="col-sm-6 col-md-8">
		                <span class="label label-default pull-right"><i class="glyphicon glyphicon-comment"></i>50</span>
		                <h4>Download Materi IV</h4>
		                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
		                <section>
		                    <i class="glyphicon glyphicon-folder-open"></i>Bootstrap
		                    <i class="glyphicon glyphicon-user"></i>RaymondDragon
		                    <i class="glyphicon glyphicon-calendar"></i>1395/12/21
		                    <i class="glyphicon glyphicon-eye-open"></i>10000
		                    <a href="#" class="btn-default btn-sm pull-right">Download ... </a>
		                </section>
		            </div>
		        </div>
		    </article>
                    <br>
		    
		    <article>
		        <div class="row">
		            <div class="col-sm-6 col-md-4">
		                <figure>
                                    <img src="<?php echo base_url('assets/asset_web/short-course.png') ?>" style="height: 100px">
		                </figure>
		            </div>
		            <div class="col-sm-6 col-md-8">
		                <span class="label label-default pull-right"><i class="glyphicon glyphicon-comment"></i>50</span>
		                <h4>Download Materi V</h4>
		                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
		                <section>
		                    <i class="glyphicon glyphicon-folder-open"></i>Bootstrap
		                    <i class="glyphicon glyphicon-user"></i>RaymondDragon
		                    <i class="glyphicon glyphicon-calendar"></i>1395/12/21
		                    <i class="glyphicon glyphicon-eye-open"></i>10000
		                    <a href="#" class="btn-default btn-sm pull-right">Download ... </a>
		                </section>
		            </div>
		        </div>
		    </article>
                    <br>
		</div>
	</div>
</div>

<script>
    $('a').click(function(){
       alert('Still in Progress Be Patient :)'); 
    });
</script>