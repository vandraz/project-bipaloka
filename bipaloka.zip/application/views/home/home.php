
	
	<body id="page-top">
		<!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
	
		<!--top-area start -->
		

		<!--welcome-hero start -->
                <section id="home" class="welcome-hero d-flex align-items-center" style="background: url(<?php echo base_url('assets/trave/images/welcome-hero/gambar.png') ?>)">
    <div class="container">
        <div class="welcome-txt" style="text-align: center;padding-top: 40%;padding-bottom: 5%">
            <h3 class="judul" style="font-weight: 550;line-height: 1;color: white">IMPROVE YOUR INDONESIAN</h3>
            <h4 class="word" style="font-weight: 550;line-height: 2;color: white">With native speaker tutors</h4>
            <button class="btn btn-primary" id="getstarted" style="width: 50%;height: auto">Get Started</button>
	</div><!--/.welcome-txt-->
    </div><!--/.container-->
</section><!--/.welcome-hero-->

<!--about start -->
<section id="home" style="text-align: center;padding-top: 5%;background-color: aliceblue;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" style="position: relative;display: inline-block">
                <div class="single-about-txt">
                    <h2 style="text-align: center">WHY BIPALOKA?</h2>
                    <img src="<?php echo base_url('assets/asset_web/ilustrasi.png') ?>">
                </div><!--/.single-about-txt-->
            </div><!--/.col-->
        </div><!--/.row-->
    </div>
                    
<div class="container-fluid" style="margin-top: -40%">
  <div class="row">
      <div class="card-deck" style="padding-left: 5%;padding-right: 3%;height: auto">
      <div class="card boxbipaloka">
        <div class="card-block">
          <h4 class="card-title"></h4>
          <div class="container">
              <div class="row">
                  <div class="col-md-2"><img src="<?php echo base_url('assets/asset_web/1on1.png') ?>" style="height: 100px;"></div>
                  <div class="col-md-8">
                      <p class="card-text word">Get 1-on-1 lesson(s) with professional native speaker tutors.</p>
          <p class="card-text"><small class="text-muted"></small></p>
        
                  </div>
          
              </div>
          </div>
        </div>
      </div>
      <div class="card boxbipaloka">
        <div class="card-block">
          <h4 class="card-title"></h4>
          <div class="container">
              <div class="row">
                  <div class="col-md-2"><img src="<?php echo base_url('assets/asset_web/culture.png') ?>" style="height: 100px"></div>
                  <div class="col-md-8">
                        <p class="card-text word">Indonesian culture based curriculum; traditional or pop.</p>
          <p class="card-text"><small class="text-muted"></small></p>
        
                  </div>
          
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    <div class="row" style="padding-top: 15%;">
      <div class="card-deck" style="padding-left: 5%;padding-right: 3%;height: auto">
          <div class="card boxbipaloka">
        <div class="card-block">
          <h4 class="card-title"></h4>
          <div class="container">
              <div class="row">
                  <div class="col-md-2"><img src="<?php echo base_url('assets/asset_web/immersion.png') ?>" style="height: 100px"></div>
                  <div class="col-md-8">
                        <p class="card-text word">Immersion language experience in every lesson.</p>
          <p class="card-text"><small class="text-muted"></small></p>
        
                  </div>
          
              </div>
          </div>
        </div>
      </div>
      <div class="card boxbipaloka">
        <div class="card-block">
          <h4 class="card-title"></h4>
          <div class="container">
              <div class="row">
                  <div class="col-md-2"><img src="<?php echo base_url('assets/asset_web/schedule.png') ?>" style="height: 100px"></div>
                  <div class="col-md-8">
                      <p class="card-text word">Anytime, anywhere. Manage schedule by yourself.</p>
          <p class="card-text"><small class="text-muted"></small></p>
        
                  </div>
          
              </div>
          </div>
        </div>
      </div>
        <br>
    </div>
  </div>
</div>
</section><!--/.about end -->

<!--gallery start-->
<section class="home" style="padding-top: 15%">
                    <div class="section-title text-center">
            <h2 style="font-size: 1">WHAT'S IN</h2>
            <h2>BILAPOKA?</h2>
        </div><!-- end title -->
        <div class="container-fluid" style="padding-top: 5%;text-align: center">
  <div class="row">
      <div class="card-deck" style="padding-left: 3%;padding-right: 3%">
      <div class="card boxbipaloka">
        <div class="card-block">
          <div class="container">
              <div class="row">
                  <div class="col-md-3"><img src="<?php echo base_url('assets/asset_web/single-course.png') ?>" style="height: 150px"></div>
                  <div class="col-md-7">
                                  <h4 class="card-title judul">Informal Tutorial</h4>
          
                        <p class="card-text word">For you that seeking a speaking partner to improve your speaking skill.</p>
          <p class="card-text"><small class="text-muted"></small></p>
        
                  </div>
          
              </div>
          </div>
        </div>
      </div>
      <div class="card boxbipaloka">
        <div class="card-block">
          <div class="container">
              <div class="row">
                  <div class="col-md-3"><img src="<?php echo base_url('assets/asset_web/short-course.png') ?>" style="height: 150px"></div>
                  <div class="col-md-7">
                      <h4 class="card-title judul">Structured Tutorial</h4>
                        <p class="card-text word">For you that want to increase your language ability through structured lessons.</p>
          <p class="card-text"><small class="text-muted"></small></p>
        
                  </div>
          
              </div>
          </div>
        </div>
      </div>
        <br>
    </div>
  </div>
    <div class="row" style="padding-top: 5%">
      <div class="card-deck" style="padding-left: 3%;padding-right: 3%">
      <div class="card boxbipaloka">
        <div class="card-block">
          <div class="container">
              <div class="row">
                  <div class="col-md-3"><img src="<?php echo base_url('assets/asset_web/slanglanguage.png') ?>" style="height: 150px"></div>
                  <div class="col-md-7">
                      <h4 class="card-title judul">Specific Purposes Tutorial (coming soon)</h4>
                        <p class="card-text word">For you who want to learn a language for a occupation or need.</p>
          <p class="card-text"><small class="text-muted"></small></p>
        
                  </div>
          
              </div>
          </div>
        </div>
      </div>
      <div class="card boxbipaloka">
        <div class="card-block">
          <div class="container">
              <div class="row">
                  <div class="col-md-3"><img src="<?php echo base_url('assets/asset_web/spesific-purpose.png') ?>" style="height: 150px"></div>
                  <div class="col-md-7">
                       <h4 class="card-title judul">Free Indonesian Test</h4>
                        <p class="card-text word">Find out your Indonesian language skills through our free tests.</p>
          <p class="card-text"><small class="text-muted"></small></p>
        
                  </div>
          
              </div>
          </div>
        </div>
      </div>
        <br>
    </div>
  </div>
</div>
		</section><!--/.gallery-->
		<!--gallery end-->
                <br>

<section id="packages" style="padding-top: 5%;background-color: #483D8B">

<div class="container">
    <!--Carousel Wrapper-->
    <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">

      <!--Controls-->
      <div class="controls-top" style="text-align: center;">
          <a class="btn btn-floating" href="#multi-item-example" data-slide="prev" style="background-color: white"><i class="fa fa-chevron-left"></i></a>
          <a class="btn btn-floating" href="#multi-item-example" data-slide="next" style="background-color: white"><i class="fa fa-chevron-right"></i></a>
      </div>
      <br>
      <!--/.Controls-->

      <!--Indicators-->
      <ol class="carousel-indicators">
        <li data-target="#multi-item-example" data-slide-to="0" class="active"></li>
        <li data-target="#multi-item-example" data-slide-to="1"></li>
        <li data-target="#multi-item-example" data-slide-to="2"></li>
      </ol>
      <!--/.Indicators-->
      <div class="row">
          <div class="col-md-3">
              <div class="section-title text-center">
            <h2 style="font-size: 1;color: whitesmoke">OUR</h2>
            <h2 style="color: whitesmoke">PACKAGES</h2><br>
            <button class="btn btn-primary" id="allpackage">View All Packages</button><br>
        </div><!-- end title -->
          </div>
          <div class="col-md-9">
              <div class="carousel-inner" role="listbox">

        <!--First slide-->
        <div class="carousel-item active" style="background-color: #483D8B">

          <div class="row">
            <div class="col-md-3">
                <div class="card" style="height: 100%">
                    <img class="card-img-top" src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>" class="profile-avatar" style="background-color: black" alt="">
                        </figure>
                        <h4 class="card-title mt-3 judul">Informal Tutorial</h4>
                        <div class="card-text word rata_tengah">
                            Get a speaking partner to improve your speaking skill.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary float-right btn-sm" id="package1">Book</button>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="height: 100%">
                    <img class="card-img-top" src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title mt-3 judul">Beginner Tutorial</h4>
                        <div class="card-text word rata_tengah">
                            Get structured lessons for beginners level and start speaking Indonesian.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary float-right btn-sm" id="package2">Book</button>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="height: 100%">
                    <img class="card-img-top" src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title mt-3 judul">Intermediate Tutorial</h4>
                        <div class="card-text word rata_tengah">
                            Get structured lessons for intermediate level and improve your language skill.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary float-right btn-sm" id="package3">Book</button>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="height: 100%">
                    <img class="card-img-top" src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title mt-3 judul">Advanced Tutorial</h4>
                        <div class="card-text word rata_tengah">
                           Get structured lessons for advanced level and make yourself like a native.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary float-right btn-sm" id="package4">Book</button>
                    </div>
                </div>
            </div>
          </div>

        </div>
        <!--/.First slide-->

        <!--Second slide-->
        <div class="carousel-item" style="background-color: #483D8B">

          <div class="row">
            <div class="col-md-3">
                <div class="card" style="height: 100%">
                    <img class="card-img-top" src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title mt-3 judul">Informal Tutorial</h4>
                        <div class="card-text word rata_tengah">
                            Get a speaking partner to improve your speaking skill.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary float-right btn-sm" id="package1">Book</button>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="height: 100%">
                    <img class="card-img-top" src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title mt-3 judul">Beginner Tutorial</h4>
                        <div class="card-text word rata_tengah">
                            Get structured lessons for beginners level and start speaking Indonesian.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary float-right btn-sm" id="package2">Book</button>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="height: 100%">
                    <img class="card-img-top" src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title mt-3 judul">Intermediate Tutorial</h4>
                        <div class="card-text word rata_tengah">
                            Get structured lessons for intermediate level and improve your language skill.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary float-right btn-sm" id="package3">Book</button>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="height: 100%">
                    <img class="card-img-top" src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="<?php echo base_url('assets/asset_web/Logo_bipa-02.jpg') ?>" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title mt-3 judul">Advanced Tutorial</h4>
                        <div class="card-text word rata_tengah">
                           Get structured lessons for advanced level and make yourself like a native.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-secondary float-right btn-sm" id="package4">Book</button>
                    </div>
                </div>
            </div>
          </div>

        </div>
        <!--/.Second slide-->
      </div>
          </div>
      </div>
      <!--Slides-->
      
      <!--/.Slides-->

    </div>
    <!--/.Carousel Wrapper-->


  </div>

</section><!--/.gallery-->

  

                
    


		<!--contact start-->
<!--/.contact-->
		<!--contact end-->

<script>
    
$( '#NavbarResponsive .navbar-nav a' ).on( 'click', function () {
	$( '#NavbarResponsive .navbar-nav' ).find( 'li.active' ).removeClass( 'active' );
	$( this ).parent( 'li' ).addClass( 'active' );
});

    
    $('#getstarted').click(function(){
        window.location.href = '<?php echo site_url('home/packages'); ?>';
    });
    $('#allpackage').click(function(){
        window.location.href = '<?php echo site_url('home/packages'); ?>';
    });
    $('#package1').click(function(){
        window.location.href = '<?php echo site_url('home/packages'); ?>';
    });
    $('#package2').click(function(){
        window.location.href = '<?php echo site_url('home/packages'); ?>';
    });
    $('#package3').click(function(){
        window.location.href = '<?php echo site_url('home/packages'); ?>';
    });
    $('#package4').click(function(){
        window.location.href = '<?php echo site_url('home/packages'); ?>';
    });
    
    
</script>
       


		
		