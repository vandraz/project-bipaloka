<div style="padding-left: 5%;background: url(<?php echo base_url('assets/trave/images/welcome-hero/gambar.png') ?>)"><br><br><br><br><br><br><br>
    <section id="about" style="padding-top: 15%">
        <div class="card" style="width: 95%;">
            <div class="card-header">
      <h3 class="judul">About Us </h3>
  </div>
  <div class="card-body">
    <h5 class="card-title"></h5>
    <p class="card-text word" style=" text-align: justify;text-justify: inter-word;">Departing from love for Indonesian, BIPALOKA is here to bring Indonesian to the world. We want to bridge foreign speakers of language lovers in order to learn directly with professional tutors - native speakers of Indonesian.
Not only introducing language, BIPALOKA and the tutor partners also have the passion to bring various linguistic situations in Indonesia. Every language teaching will always be accompanied by the cultural context that follows it. That way, the world not only knows Indonesian, but also knows more about its culture.
BIPALOKA is ready to become the entrance for world citizens to get to know Indonesia more closely.
See more about BIPALOKA on our social media.</p><br>
    
    <div class="row">
        <div class="col-md-3">
            <i class="fa fa-facebook-official" style="font-size:36px">Facebook </i>
        </div>
        <div class="col-md-9">
            <p class="word">: Bipaloka – Learn Indonesian with Native Speaker Tutors </p>
        </div>
    </div><br>
    <div class="row">
        <div class="col-md-3">
            <i class="fa fa-instagram" style="font-size:36px">Instagram </i>
        </div>
        <div class="col-md-9">
            <p class="word">: @bipaloka </p>
        </div>
    </div><br>
    <div class="row">
        <div class="col-md-3">
            <i class="fa fa-twitter" style="font-size:36px">Twitter </i>
        </div>
        <div class="col-md-9">
            <p class="word">: @bipaloka </p>
        </div>
    </div>
  </div>
</div>
    </section>
    
    </div>

<script src="<?php echo base_url(); ?>assets/trave/js/jquery.js"></script>
		

<script>
$('#menuhome').find('li active').removeClass('active')
$('#menuabout').addClass('active')
</script>