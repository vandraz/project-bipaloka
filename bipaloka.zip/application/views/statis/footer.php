
<footer id="contact"  class="contact" style="padding-top: 5%;background-color: #191970">
    <div class="footer-copyright" style="background-color: #191970">
        <div class="row">
              <div class="col-md-4"> 
                    <img src="<?php echo base_url('assets/asset_web/footer.png') ?>">
                    <h2 style="color: white;text-align: center;font-size: 25pt;padding-bottom: 20%">BIPALOKA</h2>
        </div>
        <div class="col-md-4"> 
                    <h2 style="color: white;font-size: 12">SITEMAP</h2>
                    <a href="<?php echo site_url('home/aboutus') ?>" class="word" style="color: white"> About Us ||</a>
                    <a href="<?php echo site_url('home/packages') ?>" class="word" style="color: white"> Our Packages ||</a>
                    <a href="<?php echo site_url('home/contactus') ?>" class="word" style="color: white"> Contact Us ||</a>
                    <a href="https://drive.google.com/open?id=1RlPv1xDmiaWvSNRRP-lwfy-hM7w_t7iqwwjysJXmN0Y" class="word" style="color: white"> Terms of Service</a>
                    <br>
                    <br>
                    <div id="map-container-google-1 flex" class="z-depth-1-half map-container" style="height: auto;width: auto">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d126443.65728156082!2d112.5473499335874!3d-7.961253127542387!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2stl!4v1562392060444!5m2!1sen!2stl" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
                    <br>
                    <br>
                </div>
            <div class="col-md-4"> 
                        <h2 style="color: white;font-size: 12">CONTACT US</h2>
                        <p class="word">You can reach us
                                through this
                                contacts below. <br>
                                <b>Whats App : +6285755921415</b> <br>
                                <b>Email : info@bipaloka.com</b>
                            </p>
                                <div class="col-lg-3"></div>
                                <h2 style="color: white;font-size: 12;padding-top: 5%">SOCIAL MEDIA</h2><br>
                                        <div class="row">
                                            <div class="col-md-6"><a href="https://www.instagram.com/bipaloka/"><img src="<?php echo base_url('assets/asset_web/instagram-logo.png') ?>" style="width: 50px;height: 50px"></a></div>
                                            <div class="col-md-6"><a href="https://www.facebook.com/bipaloka.indonesia/"><img src="<?php echo base_url('assets/asset_web/facebook-logo.png') ?>" style="width: 50px;height: 50px"></a></div>
                                            <!-- <div class="col-md-3"><a><img src="<?php //echo base_url('assets/asset_web/google-plus-logo.png') ?>" style="width: 50px;height: 50px"></a></div>
                                            <div class="col-md-3"><a href="https://www.youtube.com/channel/UCNoM8VUtcsXtmYjMAUzoRrA"><img src="<?php //echo base_url('assets/asset_web/youtube-logo.png') ?>" style="width: 50px;height: 50px"></a></div>
                                        --></div>
                    </div>
        </div>
      
        
    </div><!--/.footer-copyright-->
    <div id="scroll-Top">
        <div class="return-to-top">
            <i class="fa fa-angle-up " id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
	</div>
    </div><!--/.scroll-Top-->
</footer>

<!-- Include all js compiled plugins (below), or include individual files as needed -->


		<script src="<?php echo base_url(); ?>assets/trave/js/jquery.js"></script>
		
		<!-- popper js -->
		<script src="<?php echo base_url(); ?>assets/trave/js/popper.min.js"></script>
		
		<!--bootstrap.min.js-->
        <script src="<?php echo base_url(); ?>assets/trave/js/bootstrap.min.js"></script>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

        <!--Custom JS-->
        <script src="<?php echo base_url(); ?>assets/trave/js/custom_1.js"></script>

        
 	
	</body>
</html>