<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- meta data -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
        
        <!-- title of site -->
        <title>BIPALOKA</title>

        <!-- For favicon png -->
        <link rel="shortcut icon" type="image/icon" href="<?php echo base_url() ?>assets/asset_web/logo-sendiri.jpg"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/font-awesome.min.css">

		<!--animate.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/animate.css">

        <!--flaticon.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/flaticon.css">

        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/bootstrap.min.css">
        
        <!--style.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/bipa.css">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/responsive.css">
        
        
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		
        <!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>


		<!--top-area end -->
                	<script src="<?php echo base_url(); ?>assets/trave/js/jquery.js"></script>
	
                <script>
                    
                $('#menuabout').click(function(){
   window.location.href = '<?php echo site_url('home/aboutus') ?>' ;
});
             $('#menupackages').click(function(){
   window.location.href = '<?php echo site_url('home/packages') ?>' ;
});
          $('#menuhome').click(function(){
   window.location.href = '<?php echo site_url('home/') ?>' ;
});
$('#menucontact').click(function(){
   window.location.href = '<?php echo site_url('home/contactus') ?>' ;
});
                </script>

<!-- Navbar -->
<nav id="navbar-example2" class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="<?php echo base_url('assets/asset_web/Logo_bipa-03.png') ?>" style="width: 200px"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
          <a class="nav-item nav-link active" href="<?php echo site_url('home/tutor') ?>">Tutor </a>
        <a class="nav-item nav-link" href="<?php echo site_url('bookaclass/') ?>">Book a Class</a>
        <a class="nav-item nav-link" href="<?php echo site_url('schedule') ?>">Schedule</a>
        <a class="nav-item nav-link" href="<?php echo site_url('material'); ?>">Material</a>
        <a class="nav-item nav-link" href="<?php echo site_url('material/article') ?>">Explore Indonesia</a>
        <button type="button" class="btn-primary" id="login" style="width: 100px;height: 50px">Login</button>
    </div>
  </div>
</nav>

<script>
 $("a").each(function() {
    if ((window.location.pathname.indexOf($(this).attr('href'))) > -1) {
        $(this).addClass('active');
    }
  
  $('#login').click(function(){
     alert('Still in Progress Be Patient :)'); 
  });
    
});
</script>    