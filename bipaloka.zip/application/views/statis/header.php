<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- meta data -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
        
        <!-- title of site -->
        <title>BIPALOKA</title>

        <!-- For favicon png -->
        <link rel="shortcut icon" type="image/icon" href="<?php echo base_url() ?>assets/asset_web/logo-sendiri.jpg"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/font-awesome.min.css">

		<!--animate.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/animate.css">

        <!--flaticon.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/flaticon.css">

        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/bootstrap.min_1.css">
        
        <!--style.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/style_1.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/bipa_1.css">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/trave/css/responsive.css">
        
        
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		
        <!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

<section class="top-area">
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
				<div class="container">
                                    <a class="navbar-brand js-scroll-trigger" href="#page-top"><img src="<?php echo base_url('assets/asset_web/Logo_bipa-05.png') ?>" style="height: 100px"></a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
						<i class="fa fa-bars"></i>
					</button><!--/button-->
					<div class="collapse navbar-collapse nav-responsive-list" id="navbarResponsive">
                                            <ul class="navbar-nav ml-auto">
							<li class="nav-item" id="menuhome">
                                                            <a class="btn nav-link js-scroll-trigger" style="color: #F8F8FF;" href="#home">Home</a>
							</li><!--/.nav-item-->
							<li class="nav-item" id="menuabout">
								<a class="btn nav-link js-scroll-trigger" style="color: #F8F8FF" href="#about">About Us</a>
							</li><!--/.nav-item-->
                                                        <li class="nav-item" id="menupackages">
								<a class="btn nav-link js-scroll-trigger" style="color: #F8F8FF" href="#packages">Our Packages</a>
							</li><!--/.nav-item-->
                                                        <li class="nav-item" id="menucontact">
								<a class="btn nav-link js-scroll-trigger" style="color: #F8F8FF" href="#contacts">Contact Us</a>
							</li><!--/.nav-item-->
						</ul><!--/ul-->
					</div><!--/.collapse-->
				</div><!--/.container-->
			</nav><!--/nav-->
		</section><!--/.top-area-->
		<!--top-area end -->
                	<script src="<?php echo base_url(); ?>assets/trave/js/jquery.js"></script>
	
                <script>
                    
                $('#menuabout').click(function(){
   window.location.href = '<?php echo site_url('home/aboutus') ?>' ;
});
             $('#menupackages').click(function(){
   window.location.href = '<?php echo site_url('home/packages') ?>' ;
});
          $('#menuhome').click(function(){
   window.location.href = '<?php echo site_url('home/') ?>' ;
});
$('#menucontact').click(function(){
   window.location.href = '<?php echo site_url('home/contactus') ?>' ;
});
                </script>