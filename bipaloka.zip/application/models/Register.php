<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Register extends CI_Model{
    
    public function gettimetutor($idtutor){
        $data = $this->db->query("SELECT sm_timetutor.id_day,sm_day.day, sm_tutor.nama_tutor,sm_timetutor.id_time "
                . "FROM `sm_timetutor` "
                . "join sm_tutor ON sm_tutor.id_tutor = sm_timetutor.id_tutor "
                . "INNER JOIN sm_day on sm_timetutor.id_day = sm_day.id_day "
                . "INNER JOIN sm_time ON sm_timetutor.id_time=sm_time.id_time "
                . "WHERE sm_tutor.id_tutor='1'"
                . "GROUP BY sm_timetutor.id_day"
                );
        return $data->result_array();
    }
    
    public function gettimebyday($idtutor,$idday){
        $data = $this->db->query("SELECT sm_tutor.nama_tutor, sm_time.time, sm_day.day, sm_day.id_day, sm_time.id_time 
            FROM `sm_timetutor` join sm_tutor ON sm_tutor.id_tutor = sm_timetutor.id_tutor
               INNER JOIN sm_day on sm_timetutor.id_day = sm_day.id_day
               INNER JOIN sm_time on sm_timetutor.id_time = sm_time.id_time
                WHERE sm_tutor.id_tutor='$idtutor' and sm_day.id_day='$idday'");
        return $data->result_array();
    }
    
    public function getwaktu(){
        $data = $this->db->query("select * from sm_waktu");
        return $data->result_array();
    }

    

    public function insertuser(){
        $data = $this->db->query("insert into tb_user (id_user, username, password, email, id_level, id_medsos, foto, tgllahir, aktivasi) values"
                . "");
    }
    
    
    public function aktivasiuser(){
        $data = $this->db->query("update tb_user set aktivasi ='1' where id_user = $iduser");
    }
}

?>
