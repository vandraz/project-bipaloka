<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class User extends CI_Model{
    
    public function getuser(){
        $data = $this->db->query("Select * from tb_user");
        return $data->result_array();
    }
    
    
    public function insertuser(){
        $data = $this->db->query("insert into tb_user (id_user, username, password, email, id_level, id_medsos, foto, tgllahir, aktivasi) values"
                . "");
    }
    
    
    public function aktivasiuser(){
        $data = $this->db->query("update tb_user set aktivasi ='1' where id_user = $iduser");
    }
}

?>
